/*
=====================================
JAVASCRIPT DEL BANNER INTERACTIVO
DigitalMotion Studio
=====================================

REQUISITO E: COMPATIBILIDAD ENTRE NAVEGADORES
Explicación de prefijos de navegador usados en CSS
*/

console.log('Banner Interactivo DigitalMotion Studio - Cargado correctamente');

/* 
===== COMPATIBILIDAD ENTRE NAVEGADORES (REQUISITO E) =====

Los PREFIJOS DE NAVEGADOR se utilizan para propiedades CSS que están
en desarrollo o fueron implementadas de manera experimental.

PREFIJOS PRINCIPALES:
-webkit-  → Chrome, Safari, Edge moderno, Opera
-moz-     → Firefox
-ms-      → Internet Explorer, Edge antiguo
-o-       → Opera antiguo

===== PROPIEDADES CRÍTICAS CON PREFIJOS EN NUESTRO PROYECTO =====

1. TRANSFORM-STYLE: preserve-3d
   -webkit-transform-style: preserve-3d; (Safari, Chrome antiguos)
   -moz-transform-style: preserve-3d; (Firefox antiguos)

   RAZÓN: Necesario para efectos 3D. Asegura que los elementos hijos
   mantengan su posición en el espacio 3D.

2. TRANSFORM: rotateY(), scale(), translateY()
   -webkit-transform: rotateY(20deg) scale(1.15); (Safari, Chrome antiguos)
   -moz-transform: rotateY(20deg) scale(1.15); (Firefox antiguos)

   RAZÓN: Transformaciones 3D esenciales para las animaciones.
   Los navegadores antiguos requieren prefijos para soporte completo.

3. TRANSITION: all 0.5s ease
   -webkit-transition: all 0.5s ease; (Safari, Chrome antiguos)
   -moz-transition: all 0.5s ease; (Firefox antiguos)

   RAZÓN: Transiciones suaves entre estados (hover).
   Mejora la experiencia visual en todos los navegadores.

4. ANIMATION: logoEntrance 3s ease-in-out
   -webkit-animation: logoEntrance 3s ease-in-out; (Safari, Chrome antiguos)
   -moz-animation: logoEntrance 3s ease-in-out; (Firefox antiguos)

   RAZÓN: Animaciones @keyframes. Los prefijos aseguran que la animación
   de entrada funcione en navegadores más antiguos.

5. @KEYFRAMES logoEntrance / logoFloat
   @-webkit-keyframes logoEntrance { ... }
   @-moz-keyframes logoEntrance { ... }

   RAZÓN: Define las animaciones. Cada navegador antiguo necesita
   su versión con prefijo para reconocer la animación.

===== POR QUÉ SE USAN =====

Aunque los navegadores modernos (Chrome 90+, Firefox 88+, Safari 14+,
Edge 90+) soportan estas propiedades SIN prefijos, incluirlos garantiza:

✓ Compatibilidad con navegadores antiguos aún en uso
✓ Funcionamiento correcto en dispositivos móviles antiguos
✓ Experiencia consistente en todas las plataformas
✓ Cumplimiento de estándares de desarrollo web profesional

===== NAVEGADORES SOPORTADOS =====

CON PREFIJOS:
- Chrome 36+ (2014)
- Safari 9+ (2015)
- Firefox 16+ (2012)
- Edge 12+ (2015)
- Opera 23+ (2014)

SIN PREFIJOS (solo estándar):
- Chrome 90+
- Safari 14+
- Firefox 88+
- Edge 90+

===== CONCLUSIÓN =====

Los prefijos en este proyecto aseguran que el banner funcione
correctamente en aproximadamente el 99% de navegadores en uso,
incluyendo versiones antiguas que aún tienen participación de mercado.
*/

// Función opcional: Detectar capacidades del navegador
function checkBrowserSupport() {
    const el = document.createElement('div');
    const transforms = [
        'transform',
        'WebkitTransform',
        'MozTransform',
        'msTransform',
        'OTransform'
    ];

    for (let i = 0; i < transforms.length; i++) {
        if (el.style[transforms[i]] !== undefined) {
            console.log('Transformaciones 3D soportadas: ' + transforms[i]);
            return true;
        }
    }

    console.warn('Transformaciones 3D no soportadas en este navegador');
    return false;
}

// Ejecutar verificación al cargar la página
window.addEventListener('DOMContentLoaded', function() {
    checkBrowserSupport();
    console.log('Banner listo. Pasa el cursor sobre el logo para ver efectos.');
});

/*
===== RECURSOS ADICIONALES =====

Para más información sobre compatibilidad de navegadores:
- https://caniuse.com/ (Verificar soporte de propiedades CSS)
- https://developer.mozilla.org/es/ (Documentación de MDN)
- https://autoprefixer.github.io/ (Herramienta para añadir prefijos automáticamente)
*/
